import java.util.Scanner;

public class Task1 {
    public static void main(String[] args) {
        //задание: 1

        Scanner sc1 = new Scanner(System.in);
        System.out.print("Введите предыдущие покозание счетчика: ");
        int value1 = sc1.nextInt();
        Scanner sc2 = new Scanner(System.in);
        System.out.print("Введите текущее покозание счетчика: ");
        int value2 = sc2.nextInt();
        double tarif = 0.77 ;
        System.out.println("Тариф : " + tarif + "com");
        double result1 = Math.abs(value2 - value1);
        System.out.println("Вы потребили: " + result1 + "кВт");

        double result2 = 0.77 * result1 ;
        System.out.println("К оплате: " + result2 + "сом");
        // ------------------------------------
        
       
    }
}
