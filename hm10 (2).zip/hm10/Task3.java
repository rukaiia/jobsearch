public class Task3 {
    public static void main(String[] args) {
        // x = a;
        int a = 1;
        double result1 = -1 / Math.pow(a, 2);
        System.out.println("Example1: " + result1);

        // ------------------------------
        int b = 2;
        int c = 3;

        double result2 = a / (b * c);
        System.out.println("Example2: " + result2);

        // ------------------------------

        double result3 = (a / b) * c;
        System.out.println("Example3: " + result3);

        double result4 = (a + b) / 2;
        System.out.println("Example4: " + result4);
        // ----------------------------------------

        double result5 = 5.45 * ((a + 2 * b) / (2 - b));
        System.out.println("Example5: " + result5);
        // ----------------------------------------

        double result6 = (-b + Math.sqrt(Math.pow(b, 2) - 4 * a * c) ) / (2 * a);
        System.out.println("Example6: " + result6);
        // ----------------------------------------

        double result7 = (-b + (1 / a) ) / ( 2 / c);
        System.out.println("Example7: " + result7);
        // ----------------------------------------

        double result8 = 1 / ( 1 + (a + b / 2));
        System.out.println("Example8: " + result8);
        // ----------------------------------------

        double result9 = 1 / (1 + (2 + (2 + ( 3 / 5))));
        System.out.println("Example9: " + result9);
        // ----------------------------------------

        int n = 2;
        int m = 3;
        int d = 2;

        double result10 = Math.pow((Math.pow(d, 3) ), 2 );
        System.out.println("Example10: " + result10);
        // ----------------------------------------


        //бонусное задание:
        

    }

}
