
    import java.util.Scanner;

    public class Game {
        private Deck deck;
        private Hand hand;

        public Game() {
            this.deck = new Deck();
            this.hand = new Hand();
        }

        public void play() {
            System.out.println("Добро пожаловать в видеопокер!");

            dealCards();

            System.out.println("Ваша рука:");
            hand.displayHand();

            replaceCards();

            System.out.println("Ваша рука после замены:");
            hand.displayHand();
        }

        private void dealCards() {
            for (int i = 0; i < 5; i++) {
                hand.addCard(deck.takeCard());
            }
        }

        private void replaceCards() {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Введите номера карт, которые вы хотите заменить (через пробел , от 0-4):");
            String input = scanner.nextLine();
            String[] indices = input.split(" ");

            for (String index : indices) {
                try {
                    int idx = Integer.parseInt(index);
                    if (idx >= 0 && idx < 5) {
                        Card newCard = deck.takeCard();
                        hand.replaceCard(idx, newCard);
                    } else {
                        System.out.println("Неверный номер карты: " + idx);
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Некорректный ввод: " + index);
                }
            }
        }

        public static void main(String[] args) {
            Game game = new Game();
            game.play();
        }
    }


