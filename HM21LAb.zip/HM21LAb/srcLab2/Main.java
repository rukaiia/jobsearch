public class Main {
    public static void main(String[] args) {

                Deck deck = new Deck(); 

                Card drawnCard = deck.takeCard();
                System.out.print("Вытащили карту: ");
                drawnCard.cards();
                System.out.println();

                System.out.print("Возвращаем карту в колоду: ");
                deck.returnCard(drawnCard);
                drawnCard.cards();
                System.out.println();

                System.out.println("Перемешиваем колоду.");
                deck.shuffle();

                Card drawnCard2 = deck.takeCard();
                System.out.print("Вытащили еще одну карту: ");
                drawnCard2.cards();
            }
        }

