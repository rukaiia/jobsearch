
public class Task1 {
   
    public static int findMax(int a, int b, int c) {
        return Math.max(Math.max(a, b), c);
    }

    
    public static double findMax(double a, double b, double c) {
        return Math.max(Math.max(a, b), c);
    }

    public static void main(String[] args) {
       
        int intMax = findMax(5, 10, 3);
        double doubleMax = findMax(5.5, 10.2, 3.7);

        System.out.println("Максимальное целое число: " + intMax);
        System.out.println("Максимальное число с плавающей точкой: " + doubleMax);
    }
}
