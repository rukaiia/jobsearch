

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Television tv = new Television(1);
        Scanner scn = new Scanner(System.in);

        print("Текущий канал");
        print(tv.printChannel());

        print("Переключить на следующий: ");
        tv.nextChannel();
        print(tv.printChannel());

        print("Переключить на предыдущий: ");
        tv.prevChannel();
        print(tv.printChannel());

        print("Переключить на определённый канал: ");
        int num = scn.nextInt();
        tv.toChannel(num);
        print(tv.printChannel());
    }

    public static void print(String msg) {
        System.out.println(msg);
    }
}


