public class Channel {
    private String name;

    public Channel(String channelName) {
        name = channelName;
    }

    public String getName() {
        return name;
    }



}
