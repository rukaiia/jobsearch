public class Television {
    private int currentChannel;
    private int maxChannels;
    private Channel[] channels;

    public Television(int channel) {
        this(channel, 3);
    }

    public Television(int currentChannel, int maxChannels) {
        this.currentChannel = currentChannel;
        this.maxChannels = maxChannels;
        channels = new Channel[maxChannels];
        fillChannels();
    }

    public void nextChannel() {
        currentChannel = (currentChannel % maxChannels) + 1;
    }

    public void prevChannel() {
        currentChannel = (currentChannel - 2 + maxChannels) % maxChannels + 1;
    }

    public void toChannel(int channel) {
        if (channel >= 1 && channel <= maxChannels) {
            currentChannel = channel;
        } else {
            System.out.println("Недопустимый канал");
        }
    }

    private void fillChannels() {
        String[] channelNames = {"KTP", "MIR", "CTC", "NTV"};
        for (int i = 0; i < maxChannels; i++) {
            channels[i] = new Channel(channelNames[i]);
        }
    }

    public String printChannel() {
        return String.format("---------- %d ----------%n%s%n", currentChannel, getChannelName(currentChannel));
    }

    public String getChannelName(int channelNumber) {
        return channels[channelNumber - 1].getName();
    }
}


