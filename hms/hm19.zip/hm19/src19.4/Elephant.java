public class Elephant extends ChessPiece{
    public Elephant(String place, String color, String name) {
        super(place, color, name);
    }


}
