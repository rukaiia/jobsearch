public class Queen extends ChessPiece {
    public Queen(String place, String color, String name) {
        super(place, color, name);
    }


}
