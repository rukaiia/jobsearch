public class Pawn extends ChessPiece{
    public Pawn(String place, String color, String name) {
        super(place, color, name);
    }


}
