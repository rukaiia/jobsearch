public class Rook extends ChessPiece{
    public Rook(String place, String color, String name) {
        super(place, color, name);
    }


}
