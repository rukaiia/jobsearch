public class King extends ChessPiece{
    public King(String place, String color, String name) {
        super(place, color, name);
    }


}
