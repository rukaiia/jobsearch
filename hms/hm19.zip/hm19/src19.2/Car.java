public class Car extends Transport{
    public Car(String brand, String model, int speed) {
        super(brand, model, speed);
    }


    @Override
    boolean isMoving() {

        return true;
    }
}

