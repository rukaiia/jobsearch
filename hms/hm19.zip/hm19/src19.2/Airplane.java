public class Airplane extends Transport{
    public Airplane(String brand, String model, int speed) {
        super(brand, model, speed);
    }


    @Override
    boolean isMoving() {

        return true;
    }
}
