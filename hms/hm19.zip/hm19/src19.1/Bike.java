public class Bike extends Driving{
    int speed;
}
