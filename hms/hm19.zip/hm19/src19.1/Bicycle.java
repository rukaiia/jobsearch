public class Bicycle extends Driving{
    int age;
}
