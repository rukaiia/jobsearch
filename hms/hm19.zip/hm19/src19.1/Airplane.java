public class Airplane extends Flying{
    int height;
}
