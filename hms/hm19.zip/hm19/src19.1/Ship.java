public class Ship extends Floating{
    int amount;
}
