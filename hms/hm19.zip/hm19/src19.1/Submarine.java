public class Submarine extends Floating{
    int massa;

}
