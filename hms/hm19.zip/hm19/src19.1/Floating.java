public class  Floating extends Transport {

    String country;
}
