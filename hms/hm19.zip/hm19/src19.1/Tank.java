public class Tank extends Driving{
    String whichWar;
}
