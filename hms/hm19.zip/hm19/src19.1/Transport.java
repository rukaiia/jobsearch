public class Transport {
    int weight;
    String color;
    int cost;
}
