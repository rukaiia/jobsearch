public class FlyingCarpet extends Flying{
    String whichFairyTale;
}
