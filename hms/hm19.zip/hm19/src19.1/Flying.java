public class Flying extends Transport{
    int size;
}
