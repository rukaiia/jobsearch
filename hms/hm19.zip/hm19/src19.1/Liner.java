public class Liner extends Floating {
    int amountOfPeople;
}
