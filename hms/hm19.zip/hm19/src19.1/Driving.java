public class Driving extends Transport{
    String name;
}
