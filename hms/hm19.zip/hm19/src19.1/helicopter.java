public class helicopter extends Flying{
    int speedOfWings;
}
