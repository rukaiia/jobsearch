
import java.util.Scanner;

public class Task7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите элементы массива A (10 элементов, разделенных пробелом):");
        int[] arrayA = readArray(scanner);

        System.out.println("Введите элементы массива B (10 элементов, разделенных пробелом):");
        int[] arrayB = readArray(scanner);

        if (arrayA.length != arrayB.length) {
            System.out.println("Ошибка: массивы A и B содержат разное количество элементов.");
            return;
        }

        int[] arrayC = new int[arrayA.length];
        for (int i = 0; i < arrayA.length; i++) {
            arrayC[i] = arrayA[i] + arrayB[i];
        }

        System.out.println("Массив А:");
        printArray(arrayA);
        System.out.println("Массив B:");
        printArray(arrayB);
        System.out.println("Массив C:");
        printArray(arrayC);

        int max = arrayC[0];
        for (int i = 1; i < arrayC.length; i++) {
            if (arrayC[i] > max) {
                max = arrayC[i];
            }
        }
        System.out.println("Максимальное значение в массиве C = " + max);

        int min = Math.min(Math.min(arrayC[arrayC.length - 1], arrayC[arrayC.length - 2]), arrayC[arrayC.length - 3]);
        System.out.println("Минимальное из трех последних значений массива C = " + min);
    }

    public static int[] readArray(Scanner scanner) {
        int[] array = new int[10];
        for (int i = 0; i < array.length; i++) {
            array[i] = scanner.nextInt();
        }
        return array;
    }

    public static void printArray(int[] array) {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if (i < array.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }
}
