
    
import java.util.Scanner;

public class Task6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите цену товара в копейках (N < 1000):");
        int priceInKopecks = scanner.nextInt();

        if (priceInKopecks >= 1000 || priceInKopecks < 0) {
            System.out.println("Некорректный ввод.");
            return;
        }

        int rubles = priceInKopecks / 100;
        int kopecks = priceInKopecks % 100;

        String rublesWord;
        if (rubles == 1) {
            rublesWord = "рубль";
        } else if (rubles < 5) {
            rublesWord = "рубля";
        } else {
            rublesWord = "рублей";
        }

        String kopecksWord;
        if (kopecks == 1) {
            kopecksWord = "копейка";
        } else if (kopecks < 5) {
            kopecksWord = "копейки";
        } else {
            kopecksWord = "копеек";
        }

        System.out.println("Цена товара: " + rubles + " " + rublesWord + " " + kopecks + " " + kopecksWord);
    }
}
    

