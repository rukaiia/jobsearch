public class Dragon {
    private int HP;
    private int defence;
    private int strength;
    private int weapon;


    public Dragon(int healthPoints, int defence, int strength, int weapon) {
        this.HP = healthPoints;
        this.defence = defence;
        this.strength = strength;
        this.weapon = weapon;
    }



    public int getHP() {
        return HP;
    }

    public void setHP(int healthPoints) {
        this.HP = healthPoints;
    }

    public int getDefence() {
        return defence;
    }

    public void setDefence(int defence) {
        this.defence = defence;
    }

    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public int getWeapon() {
        return weapon;
    }

    public void setWeapon(int weapon) {
        this.weapon = weapon;
    }



    public void attackHero(Hero hero) {

        double randomValue = Math.random();
        if (randomValue < 0.5) {
            int dr =  this.strength + this.weapon - hero.getDefence();
            int heroh = hero.getHP() - dr;
            hero.setHP(heroh);
            System.out.println("Антагонист попал на героя! Нанесено урона: " + dr );
            System.out.println("У героя осталось жизни: " + heroh);
        } else {
            System.out.println("Антагонист не атакует.");
        }
    }


    public void dragonTurn(Hero hero) {
        System.out.println("Ход Антагонист: ");


        if (this.HP <= 0) {
            System.out.println("Антагонист проигал");
            return;
        }


        double randomValue = Math.random();


        if (randomValue < 0.5) {
            attackHero(hero);
        } else {
            System.out.println("Антагонист решил не нападать.");
        }


        if (hero.getHP() <= 0) {
            System.out.println("Герой проиграл.");
            System.exit(0);
        }
    }



   public boolean isAlive() {
      return HP > 0;
   }
}
