import java.util.List;
import java.util.Random;

public class Trader {

        private final int  loadCapacity = 45;
        private int speed = new Random().nextInt(5) + 1;
        private  int money = new Random().nextInt(130) + 470;
        private List<Goods> goods;


        public Trader(int speed, int money) {
            this.speed = speed;
            this.money = money;
        }


        public Trader() {
        }

        public int getLoadCapacity() {
            return loadCapacity;
        }

        public int getSpeed() {
            return speed;
        }

        public int getMoney() {
            return money;
        }
        public void addGoods(Goods goods){
            this.goods.add(goods);
        }

        public  void changeCity(){
            //тут метод для смены города
        }

    }

