import java.util.Random;

public class City {
    private String Japan;
    private String Italy;
    private String France;
    private String Germany;
    private String Spain;
    private  int distance = new Random().nextInt(100) + 50;


    public City(String japan, String italy, String france, String germany, String spain, int distance) {
        Japan = japan;
        Italy = italy;
        France = france;
        Germany = germany;
        Spain = spain;
        this.distance = distance;
    }

    public City() {
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public String getJapan() {
        return Japan;
    }

    public String getItaly() {
        return Italy;
    }

    public String getFrance() {
        return France;
    }

    public String getGermany() {
        return Germany;
    }

    public String getSpain() {
        return Spain;
    }

    public int getDistance() {
        return distance;
    }

}

