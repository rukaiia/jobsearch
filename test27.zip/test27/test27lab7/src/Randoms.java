import java.util.Random;

public class Randoms {
    private static final String[]
    GOODS_NAMES = {"shoes", "books", "clothes", "food"};
    private static final String[]
    EVENTS_TYPES = {"broken wheel" , "rainyday","river" , "spoiledgoods"};
    private static final String[]
    CITY_NAMES = {"France" , "Italy","Spain", "Japan", "Jermany"};
    private static final Random random = new Random();
    public static String randomGoods(){
        int goodsrandom = random.nextInt(GOODS_NAMES.length);
        return GOODS_NAMES[goodsrandom];
    }
    public static String randomCity(){
        int citysrandom = random.nextInt(CITY_NAMES.length);
        return GOODS_NAMES[citysrandom];
    }
    public static String randomEvents(){
        int evensrandom = random.nextInt(EVENTS_TYPES.length);
        return GOODS_NAMES[evensrandom];
    }

}
//нужно доработать , это кажется 3 или 4 задание. Тут рандомные вещи,events и города