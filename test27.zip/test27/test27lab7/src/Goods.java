import java.util.List;

public class Goods {
    private int weight;
    private  String typeOfGoods;
    private String qualityQWEATION;//IDK

    private int buyPrice;
    private int soldPrice;
    private List<Goods> goodsList;

    public Goods(int weight, String typeOfGoods, String qualityQWEATION, int buyPrice, int soldPrice) {
        this.weight = weight;
        this.typeOfGoods = typeOfGoods;
        this.qualityQWEATION = qualityQWEATION;
        this.buyPrice = buyPrice;
        this.soldPrice = soldPrice;
    }

    public Goods(int weight, String typeOfGoods, String qualityQWEATION) {
        this.weight = weight;
        this.typeOfGoods = typeOfGoods;
        this.qualityQWEATION = qualityQWEATION;
    }

    public int getWeight() {
        return weight;
    }

    public String getTypeOfGoods() {
        return typeOfGoods;
    }

    public String getQualityQWEATION() {
        return qualityQWEATION;
    }

    public int getPrice() {
        return buyPrice;
    }

    public int getStartPrice() {
        return soldPrice;
    }
    public void addGoods(Goods goods){
        goodsList.add(goods);
    }
    public void removeGoods(Goods goods){
        goodsList.remove(goods);
    }
    public void cleargoods(){
        goodsList.clear();
    }
    @Override
    public String toString(){
        return "Goods: " + "name: " + typeOfGoods +
                ", soldPrice: " + soldPrice + ", buyPrice: " + buyPrice;
    }
}
