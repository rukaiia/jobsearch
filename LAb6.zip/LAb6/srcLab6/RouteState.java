class RouteState implements TruckState {
    private Truck truck;

    public RouteState(Truck truck) {
        this.truck = truck;
    }

    @Override
    public void changeDriver(Driver newDriver) {
        System.out.println("Нельзя сменить водителя у грузовика в пути.");
    }

    @Override
    public void startDriving() {
        System.out.println("Грузовик уже в пути.");
    }

    @Override
    public void startRepair() {
        System.out.println("Грузовик " + truck.getName() + " отправлен на ремонт.");
        truck.setState(new RepairState(truck));
    }
}

