interface TruckState {
    void changeDriver(Driver newDriver);

    void startDriving();

    void startRepair();
}


