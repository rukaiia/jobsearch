public class Main {
    public static void main(String[] args) {
        Autobase autobase = new Autobase();
        autobase.start();
    }
}









