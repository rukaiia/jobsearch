public class SoldState implements State {
    @Override
    public void startSale(Product product) {
        System.out.println("Невозможно начать продажу товара '" + product.getName() + "' - товар уже продан.");
    }

    @Override
    public void raisePrice(Product product, double amount) {
        System.out.println("Невозможно увеличить цену товара '" + product.getName() + "' - товар уже продан.");
    }

    @Override
    public void withdraw(Product product) {
        System.out.println("Невозможно снять товар '" + product.getName() + "' с торгов - товар уже продан.");
    }

    @Override
    public void giveToTheWinner(Product product) {
        System.out.println("Невозможно выдать товар '" + product.getName() + "' покупателю - товар уже продан.");
    }
}
