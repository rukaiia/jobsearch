public class InStockState implements State {
    @Override
    public void startSale(Product product) {
        product.setState("на торгах");
        System.out.println("Товар '" + product.getName() + "' выставлен на торги.");
    }

    @Override
    public void raisePrice(Product product, double amount) {
        System.out.println("Невозможно увеличить цену товара '" + product.getName() + "'.");
    }

    @Override
    public void withdraw(Product product) {
        System.out.println("Невозможно снять товар '" + product.getName() + "' с торгов.");
    }

    @Override
    public void giveToTheWinner(Product product) {
        System.out.println("Невозможно выдать товар '" + product.getName() + "' сразу со склада.");
    }
}
