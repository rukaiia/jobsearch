public class ForSaleState implements State {
    @Override
    public void startSale(Product product) {
        System.out.println("Невозможно выставить товар '" + product.getName() + "' на торги - товар уже на торгах.");
    }

    @Override
    public void raisePrice(Product product, double amount) {
        product.setPrice(product.getPrice() + amount);
        System.out.println("Цена товара '" + product.getName() + "' увеличена на " + amount + ".");
    }

    @Override
    public void withdraw(Product product) {
        product.setState("на складе");
        System.out.println("Товар '" + product.getName() + "' снят с торгов и возвращен на склад.");
    }

    @Override
    public void giveToTheWinner(Product product) {
        if (product.getPrice() == 0) {
            System.out.println("Невозможно выдать товар '" + product.getName() + "' бесплатно.");
        } else {
            product.setState("продан");
            System.out.println("Товар '" + product.getName() + "' продан.");
        }
    }
}
