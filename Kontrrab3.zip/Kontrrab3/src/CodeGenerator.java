import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class CodeGenerator {
    public String makeCode(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            return convertToString(md.digest(input.getBytes()));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

    private String convertToString(byte[] array) {
        StringBuilder stringBuilder = new StringBuilder();
        for (byte b : array) {
            stringBuilder.append(Integer.toHexString(b & 0xff));
        }
        return stringBuilder.toString();
    }

    public String generateHonoraryCode(Product product) {
        String prefix = "";
        if (product.getPrice() >= 1000) {
            prefix = "Gold-";
        } else if (product.getPrice() >= 500) {
            prefix = "Silver-";
        } else {
            prefix = "Bronze-";
        }
        return makeCode(prefix + product.getId());
    }
}

