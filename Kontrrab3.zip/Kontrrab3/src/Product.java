public class Product {
    private String id;
    private String name;
    private double price;
    private String honoraryCode;
    private String state;

    public Product(String id, String name, double price, String state) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.state = state;
        this.honoraryCode = "";
    }


    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getHonoraryCode() {
        return honoraryCode;
    }

    public void setHonoraryCode(String honoraryCode) {
        this.honoraryCode = honoraryCode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }


    public void startSale() {
        if (state.equals("на складе")) {
            state = "на торгах";
            System.out.println("Товар '" + name + "' выставлен на торги.");
        } else {
            System.out.println("Невозможно выставить товар '" + name + "' на торги.");
        }
    }


    public void raisePrice(double amount) {
        if (state.equals("на торгах")) {
            price += amount;
            System.out.println("Цена товара '" + name + "' увеличена на " + amount + ".");
        } else {
            System.out.println("Невозможно увеличить цену товара '" + name + "'.");
        }
    }


    public void withdraw() {
        if (state.equals("на торгах")) {
            state = "на складе";
            System.out.println("Товар '" + name + "' снят с торгов и возвращен на склад.");
        } else {
            System.out.println("Невозможно снять товар '" + name + "' с торгов.");
        }
    }


    public void giveToTheWinner() {
        if (state.equals("на торгах")) {
            if (price == 0) {
                System.out.println("Невозможно выдать товар '" + name + "' бесплатно.");
            } else {
                state = "продан";
                System.out.println("Товар '" + name + "' продан.");
            }
        } else {
            System.out.println("Невозможно выдать товар '" + name + "'.");
        }
    }
}

