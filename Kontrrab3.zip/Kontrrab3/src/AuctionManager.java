import java.util.List;
import java.util.Scanner;

public class AuctionManager {
    private final ProductReader productReader;
    private final List<Product> products;

    public AuctionManager(String fileName) {
        this.productReader = new ProductReader(fileName);
        this.products = productReader.getProducts();
    }

    public void startAuction() {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        while (running) {
            displayProducts();
            System.out.print("Enter the number of the product you want to manage (0 to exit): ");
            int choice = scanner.nextInt();
            if (choice == 0) {
                running = false;
                continue;
            }
            Product product = products.get(choice - 1);
            displayProductDetails(product);
            displayMenu();
            int action = scanner.nextInt();
            switch (action) {
                case 1:
                    product.startSale();
                    break;
                case 2:
                    product.raisePrice(3);
                    break;
                case 3:
                    product.giveToTheWinner();
                    break;
                case 4:
                    product.withdraw();
                    break;
                case 5:
                    displayProductDetails(product);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        System.out.println("Exiting the program. Goodbye!");
    }

    private void displayProducts() {
        System.out.println("List of Products:");
        for (int i = 0; i < products.size(); i++) {
            System.out.println((i + 1) + ". " + products.get(i).getName());
        }
    }

    private void displayProductDetails(Product product) {
        System.out.println("Product Details:");
        System.out.println("ID: " + product.getId());
        System.out.println("Name: " + product.getName());
        System.out.println("Price: " + product.getPrice());
        System.out.println("Honorary Code: " + product.getHonoraryCode());
        System.out.println("State: " + product.getState());
    }

    private void displayMenu() {
        System.out.println("Available Actions:");
        System.out.println("1. Start Auction");
        System.out.println("2. Raise Price");
        System.out.println("3. Give to the Winner");
        System.out.println("4. Withdraw from Auction");
        System.out.println("5. Display Product Details");
    }
}

