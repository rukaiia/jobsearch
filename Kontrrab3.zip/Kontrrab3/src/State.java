
    public interface State {
        void startSale(Product product);
        void raisePrice(Product product, double amount);
        void withdraw(Product product);
        void giveToTheWinner(Product product);
    }




