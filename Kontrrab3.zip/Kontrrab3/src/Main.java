
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ProductReader reader = new ProductReader("products.json");

        List<Product> products = reader.getProducts();

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Список товаров:");
            for (int i = 0; i < products.size(); i++) {
                System.out.println((i + 1) + ". " + products.get(i).getName());
            }

            System.out.print("Введите номер товара для получения подробной информации: ");
            int choice = scanner.nextInt();

            if (choice >= 1 && choice <= products.size()) {
                Product selectedProduct = products.get(choice - 1);
                System.out.println("Подробная информация о товаре:");
                System.out.println("ID: " + selectedProduct.getId());
                System.out.println("Наименование: " + selectedProduct.getName());
                System.out.println("Цена: " + selectedProduct.getPrice());
                System.out.println("Состояние: " + selectedProduct.getState());
                System.out.println("Почетный код: " + selectedProduct.getHonoraryCode());

                while (true) {
                    System.out.println("Доступные действия:");
                    System.out.println("1. Выставить на аукцион");
                    System.out.println("2. Поднять цену");
                    System.out.println("3. Выдать победителю");
                    System.out.println("4. Снять с торгов");
                    System.out.println("5. Отобразить информацию о товаре");
                    System.out.println("6. Вернуться в меню товаров");

                    System.out.print("Введите номер действия: ");
                    int action = scanner.nextInt();

                    switch (action) {
                        case 1:
                            selectedProduct.startSale();
                            break;
                        case 2:
                            System.out.print("Введите сумму на которую нужно поднять цену: ");
                            double amount = scanner.nextDouble();
                            selectedProduct.raisePrice(amount);
                            break;
                        case 3:
                            selectedProduct.giveToTheWinner();
                            break;
                        case 4:
                            selectedProduct.withdraw();
                            break;
                        case 5:
                            System.out.println("ID: " + selectedProduct.getId());
                            System.out.println("Наименование: " + selectedProduct.getName());
                            System.out.println("Цена: " + selectedProduct.getPrice());
                            System.out.println("Состояние: " + selectedProduct.getState());

                            break;
                        case 6:
                            System.out.println("Список товаров:");
                            for (int i = 0; i < products.size(); i++) {
                                System.out.println((i + 1) + ". " + products.get(i).getName());
                            }

                            break;
                        default:
                            System.out.println("Неверный ввод.");
                    }

                    if (action == 5 || action == 6) {
                        break;
                    }
                }
            } else {
                System.out.println("Неверный выбор товара.");
            }
        }
    }
}


