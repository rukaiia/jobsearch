import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ProductReader {
    private final String fileName;

    public ProductReader(String fileName) {
        this.fileName = fileName;
    }

    public List<Product> getProducts() {
        List<Product> products = new ArrayList<>();
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader(fileName)) {
            JSONArray jsonArray = (JSONArray) parser.parse(reader);
            for (Object obj : jsonArray) {
                JSONObject jsonObject = (JSONObject) obj;
                String id = (String) jsonObject.get("id");
                String name = (String) jsonObject.get("name");
                double price = (double) jsonObject.get("price");
                String state = (String) jsonObject.get("state");
                Product product = new Product(id, name, price, state);
                products.add(product);
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
        return products;
    }
}




