public class Main {
    public static void main(String[] args) {
        EchoServer server = EchoServer.bindToPort(8080);
        server.run();


    }
}